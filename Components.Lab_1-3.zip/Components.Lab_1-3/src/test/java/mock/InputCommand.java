package mock;

import space.reodont.controller.MainContoller;

public class InputCommand implements Command {

    private MainContoller mainContoller;

    private ParserFactory parserFactory = ParserFactory.getInstance();

    InputCommand(MainContoller mainContoller) {
        this.mainContoller = mainContoller;
    }

    @Override
    public String execute(String arguments) {
        TwoArgumentParser parser = parserFactory
                .twoArgumentParser(arguments)
                .parse();
        if(parser.hasError() ){
            return parser.getErrorMessage();
        }
        String result = mainContoller.inputNumber( parser.first(), parser.second());
        return "result = " + result;
    }

}

