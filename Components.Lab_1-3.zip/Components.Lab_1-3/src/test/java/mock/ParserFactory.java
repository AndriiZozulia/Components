package mock;

class ParserFactory {
    private static ParserFactory instance;

    static ParserFactory getInstance() {
        if (instance == null) {
            instance = new ParserFactory();
        }
        return instance;
    }

    private ParserFactory() { }

    TwoArgumentParser twoArgumentParser(String input){
        return new TwoArgumentParser(input);
    }
}
