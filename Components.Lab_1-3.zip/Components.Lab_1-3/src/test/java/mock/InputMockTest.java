package mock;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;
import space.reodont.controller.MainContoller;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ParserFactory.class)
class InputMockTest {

    @Test
    void executeThreeParameter() {
        String input = "2 3 4";
        ParserFactory parserFactory = mock(ParserFactory.class);
        TwoArgumentParser parser = mock(TwoArgumentParser.class);
        when(parserFactory.twoArgumentParser(input)).thenReturn(parser);
        when(parser.parse()).thenReturn(parser);
        when(parser.hasError()).thenReturn(true);
        when(parser.getErrorMessage()).thenReturn("error");

        MainContoller mainController = mock(MainContoller.class);

        InputCommand addCommand = new InputCommand(mainController);
        ReflectionTestUtils.setField(addCommand, "parserFactory", parserFactory);

        String expected = "error";
        String actual = addCommand.execute(input);

        verifyZeroInteractions(mainController);
        verify(parserFactory).twoArgumentParser(input);
        verify(parser).parse();

        assertEquals(expected, actual);
    }

    @Test
    void executeFourFiveThenOk() {
        TwoArgumentParser parser = mock(TwoArgumentParser.class);
        ParserFactory parserFactory = mock(ParserFactory.class);
        when(parserFactory.twoArgumentParser(anyString())).thenReturn(parser);
        MainContoller controller = mock(MainContoller.class);
        when(controller.inputNumber(5d, 6d)).thenReturn("ok");
        when(parser.hasError()).thenReturn(false);
        when(parser.first()).thenReturn(5d);
        when(parser.second()).thenReturn(6d);
        when(parser.parse()).thenReturn(parser);
        InputCommand addCommand = new InputCommand(controller);
        ReflectionTestUtils.setField(addCommand, "parserFactory", parserFactory);


        String expectedResult = "result = ok";
        String actualResult = addCommand.execute("5 6");

        verify(parser).parse();
        verify(controller).inputNumber(5d, 6d);
        assertThat(actualResult, equalTo(expectedResult));
    }
}