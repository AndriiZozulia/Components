package mock;

public class TwoArgumentParser {
    private String input;
    private String errorMessage;
    private boolean isParsed = false;
    private boolean wasErrors = false;
    private double first;
    private double second;

    TwoArgumentParser(String input) {
        this.input = input;
    }

    public TwoArgumentParser() {
    }

    public TwoArgumentParser parse(String input){
        this.input = input;
        isParsed = false;
        wasErrors = false;
        parse();
        return this;
    }

    TwoArgumentParser parse(){
        isParsed = true;
        String[] args = input.split("\\s+");
        if( args.length != 2){
            errorMessage = "input should get 2 arguments";
            wasErrors = true;
            return this;
        }

        try{
            first = Double.parseDouble(args[0]);
            second = Double.parseDouble(args[1]);
        }catch (Exception ex){
            errorMessage =  "Can't parse argument";
            wasErrors = true;

        }
        return this;
    }

    boolean hasError(){
        return wasErrors;
    }

    double first(){
        if( isParsed && !wasErrors )
            return this.first;
        throw new IllegalStateException();
    }

    double second(){
        if( isParsed && !wasErrors )
            return this.second;
        throw new IllegalStateException();
    }

    String getErrorMessage() {
        return errorMessage;
    }
}
