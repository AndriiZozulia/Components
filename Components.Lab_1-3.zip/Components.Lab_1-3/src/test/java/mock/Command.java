package mock;

@FunctionalInterface
public interface Command {
    String execute(String command);
}

