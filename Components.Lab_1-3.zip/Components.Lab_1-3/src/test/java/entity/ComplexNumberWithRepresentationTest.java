package entity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import space.reodont.entity.ComplexNumberWithRepresentation;

import java.util.Optional;

class ComplexNumberWithRepresentationTest {

    @Test
    @DisplayName("Test simple algrebraic representation with positive imaginary part")
    void simpleAlgebraicRepresentation() {
        ComplexNumberWithRepresentation complexNumber = new ComplexNumberWithRepresentation();
        complexNumber.setReal(50d);
        complexNumber.setImaginary(20d);
        Assertions.assertEquals("50.0+20.0i", complexNumber.computeAlgebraicRepresentation());
    }

    @Test
    @DisplayName("Test simple algrebraic representation with negative imaginary part")
    void negativeAlgebraicRepresentation() {
        ComplexNumberWithRepresentation complexNumber = new ComplexNumberWithRepresentation();
        complexNumber.setReal(50d);
        complexNumber.setImaginary(-20d);
        Assertions.assertEquals("50.0-20.0i", complexNumber.computeAlgebraicRepresentation());
    }

    @Test
    @DisplayName("Test exponent representation with positive imaginary part")
    void simpleExponentRepresentation() {
        ComplexNumberWithRepresentation complexNumber = new ComplexNumberWithRepresentation();
        complexNumber.setReal(50d);
        complexNumber.setImaginary(20d);
        Assertions.assertEquals("53.85164807134504*e^(i*0.3805063771123649)", complexNumber.computeExponentRepresentation());
    }

    @Test
    @DisplayName("Test exponent representation with negative imaginary part")
    void negativeExponentRepresentation() {
        ComplexNumberWithRepresentation complexNumber = new ComplexNumberWithRepresentation();
        complexNumber.setReal(50d);
        complexNumber.setImaginary(-20d);
        Assertions.assertEquals("53.85164807134504*e^(i*-0.3805063771123649)", complexNumber.computeExponentRepresentation());
    }

    @Test
    @DisplayName("Stupid getter/setter test")
    void getterSetterTest() {
        ComplexNumberWithRepresentation complexNumberWithRepresentation = new ComplexNumberWithRepresentation(22d, 24d);
        Assertions.assertDoesNotThrow(()->complexNumberWithRepresentation.setImaginary(23d));
        Assertions.assertDoesNotThrow(()->complexNumberWithRepresentation.setReal(23d));
        Assertions.assertEquals(23d, complexNumberWithRepresentation.getImaginary(), .01d);
        Assertions.assertEquals(23d, complexNumberWithRepresentation.getReal(),.01d);
    }

}
