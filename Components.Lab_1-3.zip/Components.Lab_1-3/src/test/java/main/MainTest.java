package main;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import space.reodont.Main;
import space.reodont.entity.ComplexNumber;
import space.reodont.entity.ComplexNumberContract;
import space.reodont.entity.ComplexNumberWithRepresentation;

import java.io.IOException;

class MainTest {

    @Test
    @DisplayName("Successful reflection examining")
    void successfulAnnotationSearch() {
        Assertions.assertDoesNotThrow(()->Main.firstTask(ComplexNumberWithRepresentation.class));
    }

    @Test
    @DisplayName("Another class reflection examining")
    void anotherReflectionExamining() {
        Assertions.assertDoesNotThrow(()->Main.firstTask(String.class));
    }

    @Test
    @DisplayName("Custom class info")
    void customClassInfo() {
        Assertions.assertEquals("ComplexNumber", Main.secondTask(ComplexNumber.class));
    }

    @Test
    @DisplayName("Basic class info")
    void standartClassInfo() {
        Assertions.assertEquals("String", Main.secondTask(String.class));
    }

    @Test
    @DisplayName("Proxy complex number to prohibit setters")
    void accessProxy() {
        ComplexNumberWithRepresentation complexNumberWithRepresentation = new ComplexNumberWithRepresentation(40d, 12d);
        Assertions.assertDoesNotThrow(()->complexNumberWithRepresentation.setReal(100d));
        ComplexNumberContract complexNumberContract = Main.proxyComplexNumberClass(complexNumberWithRepresentation);
        Assertions.assertThrows(UnsupportedOperationException.class, ()->complexNumberContract.setReal(40d));
    }

    @Test
    @DisplayName("All functionality")
    void allInOne() {
        Assertions.assertThrows(UnsupportedOperationException.class,()->Main.main(new String[]{}));
    }

    @Test
    @DisplayName("Test third task")
    void thirdTask() {
        Assertions.assertThrows(UnsupportedOperationException.class, Main::thirdTask);
    }

}
