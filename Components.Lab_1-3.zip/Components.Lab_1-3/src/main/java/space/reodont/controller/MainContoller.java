package space.reodont.controller;

import space.reodont.entity.ComplexNumberWithRepresentation;
import space.reodont.view.ViewService;

public class MainContoller {

    private ComplexNumberWithRepresentation complexNumber;

    public MainContoller(ComplexNumberWithRepresentation numberWithRepresentation) {
        complexNumber = numberWithRepresentation;
    }

    public String inputNumber(Double real, Double imaginary) {
        complexNumber.setReal(real);
        complexNumber.setImaginary(imaginary);
        return ViewService.sayOk();
    }

}
