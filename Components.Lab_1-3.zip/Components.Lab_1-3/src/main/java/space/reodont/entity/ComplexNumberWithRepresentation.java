package space.reodont.entity;

import space.reodont.annotation.Lab;

import java.util.Objects;

public class ComplexNumberWithRepresentation extends ComplexNumber {

    private String representation;
    private String exponentRepresentation;

    public ComplexNumberWithRepresentation() {

    }

    public ComplexNumberWithRepresentation(Double real, Double imaginary) {
        super(real, imaginary);
    }

    public String getRepresentation() {
        return representation;
    }


    public void setRepresentation(String representation) {
        this.representation = representation;
    }

    public String getExponentRepresentation() {
        return exponentRepresentation;
    }


    public void setExponentRepresentation(String exponentRepresentation) {
        this.exponentRepresentation = exponentRepresentation;
    }

    @Lab
    public String computeExponentRepresentation() {
        String exp = String.format("%s*e^(i*%s)", computeModulus(real, imaginary), computePhi(real, imaginary));
        exponentRepresentation = exp;
        return exp;
    }

    @Lab
    public String computeAlgebraicRepresentation() {
        String alg = String.format("%s%s%si", real.toString(), imaginary >= 0 ? "+" : "" , imaginary.toString());
        representation = alg;
        return alg;
    }



    private Double computeModulus(Double firstNumber, Double secondNumber) {
        return Math.sqrt(firstNumber*firstNumber + secondNumber*secondNumber);
    }

    private Double computePhi(Double firstNumber, Double secondNumber) {
        return Math.atan(secondNumber/firstNumber);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ComplexNumberWithRepresentation that = (ComplexNumberWithRepresentation) o;
        return Objects.equals(getRepresentation(), that.getRepresentation()) &&
                Objects.equals(getExponentRepresentation(), that.getExponentRepresentation());
    }

    @Lab
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getRepresentation(), getExponentRepresentation());
    }

    @Lab
    @Override
    public String toString() {
        return "ComplexNumberWithRepresentation{" +
                "representation='" + representation + '\'' +
                ", exponentRepresentation='" + exponentRepresentation + '\'' +
                '}';
    }
}
