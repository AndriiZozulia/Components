package space.reodont.entity;

import space.reodont.annotation.Lab;

import java.util.Objects;

public abstract  class ComplexNumber implements ComplexNumberContract {

    Double real;
    Double imaginary;

    ComplexNumber() {}

    ComplexNumber(Double real, Double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    @Lab
    public Double getReal() {
        return real;
    }

    public void setReal(Double real) {
        this.real = real;
    }

    @Lab
    public Double getImaginary() {
        return imaginary;
    }

    public void setImaginary(Double imaginary) {
        this.imaginary = imaginary;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComplexNumber that = (ComplexNumber) o;
        return Objects.equals(getReal(), that.getReal()) &&
                Objects.equals(getImaginary(), that.getImaginary());
    }

    @Lab
    @Override
    public int hashCode() {
        return Objects.hash(getReal(), getImaginary());
    }

    @Lab
    @Override
    public String toString() {
        return "ComplexNumber{" +
                "real=" + real +
                ", imaginary=" + imaginary +
                '}';
    }
}
