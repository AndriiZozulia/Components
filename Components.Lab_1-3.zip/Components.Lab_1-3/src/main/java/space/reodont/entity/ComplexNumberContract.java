package space.reodont.entity;

import space.reodont.annotation.Lab;

public interface ComplexNumberContract {
    String computeExponentRepresentation();
    String computeAlgebraicRepresentation();
    String getRepresentation();
    void setRepresentation(String representation);
    String getExponentRepresentation();
    void setExponentRepresentation(String exponentRepresentation);
    public Double getReal();
    public void setReal(Double real);
    public Double getImaginary();
    public void setImaginary(Double imaginary);
}
