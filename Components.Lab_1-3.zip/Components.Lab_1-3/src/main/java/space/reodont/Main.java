package space.reodont;

import space.reodont.annotation.Lab;
import space.reodont.entity.ComplexNumber;
import space.reodont.entity.ComplexNumberContract;
import space.reodont.entity.ComplexNumberWithRepresentation;
import space.reodont.proxy.AccessProxy;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class Main {

    public static void main(String[] args) throws Exception {
        firstTask(ComplexNumber.class);
        firstTask(ComplexNumberWithRepresentation.class);
        secondTask(ComplexNumber.class);
        secondTask(ComplexNumberWithRepresentation.class);
        thirdTask();
    }

    public static void firstTask(Class examinedClass) throws Exception{
        ComplexNumberWithRepresentation complexNumberWithRepresentation = new ComplexNumberWithRepresentation();
        complexNumberWithRepresentation.setReal(10d);
        complexNumberWithRepresentation.setImaginary(20d);
        complexNumberWithRepresentation.computeAlgebraicRepresentation();
        complexNumberWithRepresentation.computeExponentRepresentation();
        System.out.println(String.format("TASK 1, class %s", examinedClass.getSimpleName()));
        Method[] methods = examinedClass.getMethods();
        for (Method method : methods) {
            System.out.println(String.format("Method %s:  ", method.getName()));
            Annotation[] annotations =  method.getAnnotations();
            for (Annotation annotation : annotations) {
                System.out.println(String.format("Annotation %s ", annotation.getClass().getCanonicalName()));
                if (annotation.annotationType() == Lab.class) {
                    System.out.println(String.format("Lab annotation found, invoking: %s", method.invoke(complexNumberWithRepresentation)));
                }
            }
            System.out.println("Args types: ");
            Class<?>[] parameterClasses =  method.getParameterTypes();
            for (Class tempClass : parameterClasses) {
                System.out.println(String.format("Type: %s", tempClass.getCanonicalName()));
            }
        }
    }

    public static String secondTask(Class examinedClass) {
        System.out.println(String.format("TASK 2, class %s", examinedClass.getSimpleName()));
        System.out.println(String.format("Class name: %s %nClass package: %s %n", examinedClass.getSimpleName(), examinedClass.getPackage().getName()));
        return examinedClass.getSimpleName();
    }

    public static void thirdTask() {
        ComplexNumberContract complexNumberWithRepresentation = new ComplexNumberWithRepresentation(50d, 60d);
        complexNumberWithRepresentation.computeAlgebraicRepresentation();
        System.out.println(String.format("TASK 3 %nLet`s create some complex number: %s",complexNumberWithRepresentation.getRepresentation()));
        complexNumberWithRepresentation.computeExponentRepresentation();
        System.out.println(String.format("%nAnd this is exp representation: %s", complexNumberWithRepresentation.getExponentRepresentation()));
        complexNumberWithRepresentation.setReal(10d);
        complexNumberWithRepresentation.computeAlgebraicRepresentation();
        System.out.println(String.format("Now we will change complex number: %s", complexNumberWithRepresentation.getRepresentation()));
        System.out.println("Well, this is working, now we will try with proxy!");
        ComplexNumberContract proxyTarget = new ComplexNumberWithRepresentation(22d, 235d);
        ComplexNumberContract proxyNumber = proxyComplexNumberClass(proxyTarget);
        System.out.println(String.format("Try stringify object: %s", proxyNumber.toString()));
        System.out.println("Well, this is working, now we will try setReal()!");
        //proxyNumber.setReal(20d);
    }

    public static ComplexNumberContract proxyComplexNumberClass(ComplexNumberContract complexNumberContract) {
        return (ComplexNumberContract) Proxy.newProxyInstance(
                ComplexNumberContract.class.getClassLoader(),
                new Class[] { ComplexNumberContract.class },
                new AccessProxy(complexNumberContract));
    }

}
