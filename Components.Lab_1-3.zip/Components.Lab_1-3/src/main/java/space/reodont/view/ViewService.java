package space.reodont.view;

public class ViewService {

    public static String sayOk() {
        System.out.println("OK");
        return "ok";
    }

}
