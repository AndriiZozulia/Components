package model.subscriber;

import model.observable.Subject;

public interface Observer {

    public void update();

    public void setSubject(Subject sub);
}
