package model.visitor;

import model.entity.Book;
import model.entity.Fruit;

public interface ShoppingCartVisitor {
    int visit(Book book);
    int visit(Fruit fruit);
}
