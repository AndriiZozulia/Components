import model.color.entity.BlueColor;
import model.color.entity.RedColor;
import model.shape.Shape;
import model.shape.entity.Pentagon;
import model.shape.entity.Triangle;

public class Main {

    public static void main(String[] args) {
        Shape tri = new Triangle(new RedColor());
        tri.applyColor();

        Shape pent = new Pentagon(new BlueColor());
        pent.applyColor();
    }

}
