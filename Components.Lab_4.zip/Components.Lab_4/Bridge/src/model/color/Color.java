package model.color;

public interface Color {
    void applyColor();
}
