package model.color.entity;

import model.color.Color;

public class BlueColor implements Color {
    public void applyColor(){
        System.out.println("blue.");
    }
}
