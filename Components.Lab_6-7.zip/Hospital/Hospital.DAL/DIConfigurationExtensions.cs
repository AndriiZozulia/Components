﻿using Hospital.DAL.Context;
using Hospital.DAL.Repositories;
using Hospital.DAL.Repositories.Abstractions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Hospital.DAL
{
    public static class DIConfigurationExtensions
    {
        public static IServiceCollection AddDALServices(this IServiceCollection services)
        {
            services.AddScoped<IDoctorRepository, DoctorRepository>();
            services.AddScoped<IClientRepository, ClientRepository>();
            services.AddScoped<IAppointmentRepository, AppointmentRepository>();

            services.AddDbContext<HospitalContext>(builder => 
                builder.UseSqlServer("Server=localhost;User Id=sa;Password=Qwert12345;Database=Hospital;"));

            return services;
        }
    }
}

