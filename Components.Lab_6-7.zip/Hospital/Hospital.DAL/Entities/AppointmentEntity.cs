﻿using System;

namespace Hospital.DAL.Entities
{
    public class AppointmentEntity
    {
        public int Id { get; set; }

        public Guid DoctorId { get; set; }
        public DoctorEntity Doctor { get; set; }

        public Guid ClientId { get; set; }
        public ClientEntity Client { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
