﻿using System;

namespace Hospital.DAL.Entities
{
    public class ScheduleEntity
    {
        public int Id { get; set; }
        public TimeSpan AcceptanceDuration { get; set; }
        public TimeSpan AcceptanceStart { get; set; }
        public TimeSpan AcceptanceEnd { get; set; }
    }
}
