﻿using System;

namespace Hospital.DAL.Entities
{
    public class ClientEntity
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
