﻿using System;

namespace Hospital.DAL.Entities
{
    public class DoctorEntity
    {
        public Guid Id { get; set; }
        public int DoctorType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int RoomNumber { get; set; }

        public int ScheduleId { get; set; }
        public ScheduleEntity Schedule { get; set; }
    }
}
