﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.DAL.Entities;

namespace Hospital.DAL.Repositories.Abstractions
{
    public interface IAppointmentRepository
    {
        Task<IReadOnlyCollection<AppointmentEntity>> GetAllByDoctorIdAsync(Guid id);
        Task<IReadOnlyCollection<AppointmentEntity>> GetAllByClientIdAsync(Guid id);

        Task AddAsync(AppointmentEntity appointment);
    }
}
