﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.DAL.Entities;

namespace Hospital.DAL.Repositories.Abstractions
{
    public interface IDoctorRepository
    {
        Task<IReadOnlyCollection<DoctorEntity>> GetAllAsync();
        Task<DoctorEntity> GetAsync(Guid id);
        Task AddAsync(DoctorEntity client);
    }
}
