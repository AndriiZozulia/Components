﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.DAL.Entities;

namespace Hospital.DAL.Repositories.Abstractions
{
    public interface IClientRepository
    {
        Task<IReadOnlyCollection<ClientEntity>> GetAllAsync();
        Task<ClientEntity> GetAsync(Guid id);

        Task AddAsync(ClientEntity client);
    }
}
