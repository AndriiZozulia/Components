﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hospital.DAL.Context;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace Hospital.DAL.Repositories
{
    public class AppointmentRepository : IAppointmentRepository
    {
        private readonly HospitalContext _context;

        public AppointmentRepository(HospitalContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IReadOnlyCollection<AppointmentEntity>> GetAllByDoctorIdAsync(Guid id)
        {
            var entities = await _context.Appointments
                .Where(appointment => appointment.Doctor.Id == id)
                .Include(entity => entity.Client)
                .Include(entity => entity.Doctor)
                .ThenInclude(entity => entity.Schedule)
                .ToListAsync();

            return entities;
        }

        public async Task<IReadOnlyCollection<AppointmentEntity>> GetAllByClientIdAsync(Guid id)
        {
            var entities = await _context.Appointments
                .Where(appointment => appointment.Client.Id == id)
                .Include(entity => entity.Client)
                .Include(entity => entity.Doctor)
                .ThenInclude(entity => entity.Schedule)
                .ToListAsync();

            return entities;
        }

        public async Task AddAsync(AppointmentEntity appointment)
        {
            if (appointment == null)
                throw new ArgumentNullException(nameof(appointment));

            await _context.Appointments.AddAsync(appointment);
            await _context.SaveChangesAsync();
        }
    }
}
