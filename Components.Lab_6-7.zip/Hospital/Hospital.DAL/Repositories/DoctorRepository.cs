﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.DAL.Context;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace Hospital.DAL.Repositories
{
    public class DoctorRepository : IDoctorRepository
    {
        private readonly HospitalContext _context;

        public DoctorRepository(HospitalContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }


        public async Task<IReadOnlyCollection<DoctorEntity>> GetAllAsync()
        {
            var entities = await _context.Doctors
                .Include(doctor => doctor.Schedule)
                .ToListAsync();

            return entities;
        }

        public Task<DoctorEntity> GetAsync(Guid id)
        {
            return _context.Doctors
                .Include(entity => entity.Schedule)
                .FirstAsync(entity => entity.Id == id);
        }
        
        public async Task AddAsync(DoctorEntity client)
        {
            if (client == null)
                throw new ArgumentNullException(nameof(client));

            await _context.Doctors.AddAsync(client);
            await _context.SaveChangesAsync();
        }
    }
}
