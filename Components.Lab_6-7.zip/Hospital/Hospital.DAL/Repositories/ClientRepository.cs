﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.DAL.Context;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace Hospital.DAL.Repositories
{
    public class ClientRepository : IClientRepository
    {
        private readonly HospitalContext _context;

        public ClientRepository(HospitalContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IReadOnlyCollection<ClientEntity>> GetAllAsync()
        {
            var entities = await _context.Clients.ToListAsync();

            return entities;
        }

        public Task<ClientEntity> GetAsync(Guid id)
        {
            return _context.Clients.FindAsync(id);
        }

        public async Task AddAsync(ClientEntity client)
        {
            if (client == null)
                throw new ArgumentNullException(nameof(client));

            await _context.Clients.AddAsync(client);
            await _context.SaveChangesAsync();
        }
    }
}
