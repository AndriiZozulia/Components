﻿using Hospital.DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace Hospital.DAL.Context
{
    public class HospitalContext : DbContext
    {
        public DbSet<DoctorEntity> Doctors { get; set; }
        public DbSet<ClientEntity> Clients { get; set; }
        public DbSet<AppointmentEntity> Appointments { get; set; }

        public HospitalContext()
        {

        }

        public HospitalContext(DbContextOptions<HospitalContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Server=localhost;User Id=sa;Password=Qwert12345;Database=Hospital;");

            base.OnConfiguring(optionsBuilder);
        }
    }
}
