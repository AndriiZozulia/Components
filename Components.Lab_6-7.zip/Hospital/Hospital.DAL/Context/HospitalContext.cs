﻿using Hospital.DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace Hospital.DAL.Context
{
    /*public class HospitalContext : DbContext
    {
        private DbSet<DoctorEntity> Doctors { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Server=localhost;User Id=sa;Password=Qwerty12345;");

            base.OnConfiguring(optionsBuilder);
        }
    }*/
}
