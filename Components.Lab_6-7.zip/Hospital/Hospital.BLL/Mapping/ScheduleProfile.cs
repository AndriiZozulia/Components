﻿using AutoMapper;
using Hospital.BLL.Models.Schelude;
using Hospital.BLL.Models.Schelude.Abstractions;
using Hospital.DAL.Entities;

namespace Hospital.BLL.Mapping
{
    public class ScheduleProfile : Profile
    {
        public ScheduleProfile()
        {
            CreateMap<ScheduleEntity, ISchedule>()
                .ConstructUsing(entity =>
                    new Schedule(entity.AcceptanceDuration, entity.AcceptanceStart, entity.AcceptanceEnd));

            CreateMap<ISchedule, ScheduleEntity>()
                .ConstructUsing(schedule => new ScheduleEntity()
                {
                    AcceptanceDuration = schedule.AcceptanceDuration,
                    AcceptanceEnd = schedule.AcceptanceEnd,
                    AcceptanceStart = schedule.AcceptanceStart
                });
        }
    }
}
