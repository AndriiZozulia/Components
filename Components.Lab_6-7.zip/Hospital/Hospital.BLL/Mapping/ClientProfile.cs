﻿using AutoMapper;
using Hospital.BLL.Models.Clients;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.DAL.Entities;

namespace Hospital.BLL.Mapping
{
    public class ClientProfile : Profile
    {
        public ClientProfile()
        {
            CreateMap<IClient, ClientEntity>()
                .ConstructUsing(client => new ClientEntity()
                {
                    Id = client.Id,
                    LastName = client.LastName,
                    FirstName = client.FirstName
                });

            CreateMap<ClientEntity, IClient>()
                .ConstructUsing(entity => new Client(entity.Id, entity.FirstName, entity.LastName));
        }
    }
}
