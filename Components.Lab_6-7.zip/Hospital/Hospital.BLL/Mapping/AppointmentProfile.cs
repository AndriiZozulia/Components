﻿using AutoMapper;
using Hospital.BLL.Models.Appointments;
using Hospital.BLL.Models.Appointments.Abstractions;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.DAL.Entities;

namespace Hospital.BLL.Mapping
{
    public class AppointmentProfile : Profile
    {
        public AppointmentProfile()
        {
            CreateMap<AppointmentEntity, IAppointment>()
                .ConstructUsing((entity, context) => 
                    new Appointment(
                        context.Mapper.Map<IDoctor>(entity.Doctor),
                        context.Mapper.Map<IClient>(entity.Client),
                        entity.StartDate,
                        entity.EndDate));

            CreateMap<IAppointment, AppointmentEntity>()
                .ConstructUsing((appointment, context) => new AppointmentEntity()
                {
                    Client = context.Mapper.Map<ClientEntity>(appointment.Client),
                    Doctor = context.Mapper.Map<DoctorEntity>(appointment.Doctor),
                    EndDate = appointment.EndDate,
                    StartDate = appointment.StartDate
                });
        }
    }
}
