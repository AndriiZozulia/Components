﻿using AutoMapper;
using Hospital.BLL.Models.Doctors;
using Hospital.DAL.Entities;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.BLL.Models.Schelude.Abstractions;

namespace Hospital.BLL.Mapping
{
    public class DoctorProfile : Profile
    {
        public DoctorProfile()
        {
            CreateMap<DoctorEntity, IDoctor>()
                .ConstructUsing((entity, context) => new Doctor(
                    entity.Id,
                    (DoctorTypes) entity.DoctorType, 
                    entity.FirstName, 
                    entity.LastName, 
                    entity.RoomNumber,
                    context.Mapper.Map<ISchedule>(entity.Schedule)));

            CreateMap<IDoctor, DoctorEntity>()
                .ConstructUsing((doctor, context) => new DoctorEntity()
                {
                    Schedule = context.Mapper.Map<ScheduleEntity>(doctor.Schedule),
                    Id = doctor.Id,
                    LastName = doctor.LastName,
                    FirstName = doctor.FirstName,
                    RoomNumber = doctor.RoomNumber,
                    DoctorType = (int) doctor.Type
                });
        }
    }
}
