﻿using AutoMapper;
using Hospital.BLL.Services;
using Hospital.BLL.Services.Abstractions;
using Hospital.DAL;
using Microsoft.Extensions.DependencyInjection;

namespace Hospital.BLL
{
    public static class DIConfigurationExtensions
    {
        public static IServiceCollection AddBLLServices(this IServiceCollection services)
        {
            services.AddScoped<IDoctorService, DoctorService>();
            services.AddScoped<IClientService, ClientService>();
            services.AddScoped<IAppointmentService, AppointmentService>();

            services.AddDALServices();

            services.AddAutoMapper();

            return services;
        }
    }
}
