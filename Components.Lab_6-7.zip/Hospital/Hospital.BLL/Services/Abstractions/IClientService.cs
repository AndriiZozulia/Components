﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.BLL.Models.Clients.Abstractions;

namespace Hospital.BLL.Services.Abstractions
{
    public interface IClientService
    {
        Task<IReadOnlyCollection<IClient>> GetAllAsync();
        Task<IClient> GetAsync(Guid id);

        Task AddAsync(IClient client);
    }
}
