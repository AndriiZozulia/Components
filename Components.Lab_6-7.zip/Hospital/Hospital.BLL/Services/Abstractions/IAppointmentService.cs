﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.BLL.Models.Appointments.Abstractions;

namespace Hospital.BLL.Services.Abstractions
{
    public interface IAppointmentService
    {
        Task<IReadOnlyCollection<IAppointment>> GetAllByDoctorIdAsync(Guid id);
        Task<IReadOnlyCollection<IAppointment>> GetAllByClientIdAsync(Guid id);

        Task CreateAppointmentAsync(DateTime startDate, DateTime endDate, Guid clientId, Guid doctorId);
    }
}
