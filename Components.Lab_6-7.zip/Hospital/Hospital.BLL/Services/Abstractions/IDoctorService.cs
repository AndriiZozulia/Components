﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital.BLL.Models.Doctors.Abstractions;

namespace Hospital.BLL.Services.Abstractions
{
    public interface IDoctorService
    {
        Task<IReadOnlyCollection<IDoctor>> GetAllAsync();
        Task<IDoctor> GetAsync(Guid id);
        
        Task AddAsync(IDoctor client);
    }
}
