﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;

namespace Hospital.BLL.Services
{
    public class DoctorService : IDoctorService
    {
        private readonly IDoctorRepository _doctorRepository;
        private readonly IMapper _mapper;

        public DoctorService(
            IDoctorRepository doctorRepository,
            IMapper mapper)
        {
            _doctorRepository = doctorRepository ?? throw new ArgumentNullException(nameof(doctorRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<IReadOnlyCollection<IDoctor>> GetAllAsync()
        {
            var entities = await _doctorRepository.GetAllAsync();

            return _mapper.Map<IReadOnlyCollection<IDoctor>>(entities);
        }

        public async Task<IDoctor> GetAsync(Guid id)
        {
            var entity = await _doctorRepository.GetAsync(id);

            return _mapper.Map<IDoctor>(entity);
        }
        
        public Task AddAsync(IDoctor client)
        {
            var entity = _mapper.Map<DoctorEntity>(client);

            return _doctorRepository.AddAsync(entity);
        }
    }
}
