﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Exceptions;
using Hospital.BLL.Models.Appointments.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;

namespace Hospital.BLL.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IDoctorRepository _doctorRepository;
        private readonly IMapper _mapper;

        public AppointmentService(
            IAppointmentRepository appointmentRepository,
            IClientRepository clientRepository,
            IDoctorRepository doctorRepository,
            IMapper mapper)
        {
            _appointmentRepository =
                appointmentRepository ?? throw new ArgumentNullException(nameof(appointmentRepository));
            _clientRepository = clientRepository ?? throw new ArgumentNullException(nameof(clientRepository));
            _doctorRepository = doctorRepository ?? throw new ArgumentNullException(nameof(doctorRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<IReadOnlyCollection<IAppointment>> GetAllByDoctorIdAsync(Guid id)
        {
            var entities = await _appointmentRepository.GetAllByDoctorIdAsync(id);

            var appointments = _mapper.Map<IReadOnlyCollection<IAppointment>>(entities);

            return appointments;
        }

        public async Task<IReadOnlyCollection<IAppointment>> GetAllByClientIdAsync(Guid id)
        {
            var entities = await _appointmentRepository.GetAllByClientIdAsync(id);

            var appointments = _mapper.Map<IReadOnlyCollection<IAppointment>>(entities);

            return appointments;
        }

        public async Task CreateAppointmentAsync(DateTime startDate, DateTime endDate, Guid clientId, Guid doctorId)
        {
            var client = await _clientRepository.GetAsync(clientId);

            if (client == null)
                throw new ValidationException("client not found");

            var doctor = await _doctorRepository.GetAsync(doctorId);

            if (doctor == null)
                throw new ValidationException("doctor not found");

            var entity = new AppointmentEntity()
            {
                StartDate = startDate,
                EndDate = endDate,
                ClientId = clientId,
                DoctorId = doctorId
            };

            await _appointmentRepository.AddAsync(entity);
        }
    }
}
