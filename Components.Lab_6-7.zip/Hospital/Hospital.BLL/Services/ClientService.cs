﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.DAL.Entities;
using Hospital.DAL.Repositories.Abstractions;

namespace Hospital.BLL.Services
{
    public class ClientService: IClientService
    {
        private readonly IClientRepository _clientRepository;
        private readonly IMapper _mapper;

        public ClientService(
            IClientRepository clientRepository,
            IMapper mapper)
        {
            _clientRepository = clientRepository ?? throw new ArgumentNullException(nameof(clientRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<IReadOnlyCollection<IClient>> GetAllAsync()
        {
            var clientEntities = await _clientRepository.GetAllAsync();

            var clients = _mapper.Map<IReadOnlyCollection<IClient>>(clientEntities);

            return clients;
        }

        public async Task<IClient> GetAsync(Guid id)
        {
            var entity = await _clientRepository.GetAsync(id);

            var client = _mapper.Map<IClient>(entity);

            return client;
        }

        public Task AddAsync(IClient client)
        {
            var entity = _mapper.Map<ClientEntity>(client);

            return _clientRepository.AddAsync(entity);
        }
    }
}
