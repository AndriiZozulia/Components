﻿using System;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Models.Core.Abstractions;

namespace Hospital.BLL.Models.Clients
{
    public class Client : EntityBase<Guid>, IClient
    {
        public string FirstName { get; }
        public string LastName { get; }

        public Client(
            Guid id,
            string firstName,
            string lastName) : base(id)
        {
            if (id == Guid.Empty)
                throw new ArgumentException(nameof(id));

            if (string.IsNullOrEmpty(firstName))
                throw new ArgumentException(nameof(firstName));

            if (string.IsNullOrEmpty(lastName))
                throw new ArgumentException(nameof(lastName));

            FirstName = firstName;
            LastName = lastName;
        }
    }
}
