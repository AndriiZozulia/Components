﻿using System;
using Hospital.BLL.Models.Core.Abstractions;

namespace Hospital.BLL.Models.Clients.Abstractions
{
    public interface IClient : IEntity<Guid>
    {
        string FirstName { get; }
        string LastName { get; }
    }
}
