﻿namespace Hospital.BLL.Models.Core.Abstractions
{
    public interface IEntity<TId>
    {
        TId Id { get; }
    }
}
