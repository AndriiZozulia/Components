﻿using System;
using Hospital.BLL.Models.Schelude.Abstractions;

namespace Hospital.BLL.Models.Schelude
{
    public class Schedule : ISchedule
    {
        public TimeSpan AcceptanceDuration { get; }
        public TimeSpan AcceptanceStart { get; }
        public TimeSpan AcceptanceEnd { get; }

        public Schedule(
            TimeSpan acceptanceDuration,
            TimeSpan acceptanceStart,
            TimeSpan acceptanceEnd)
        {
            if (acceptanceStart >= acceptanceEnd)
                throw new ArgumentException($"{nameof(acceptanceEnd)} must be greater than {nameof(acceptanceStart)}");

            if (acceptanceStart + acceptanceDuration >= acceptanceEnd)
                throw new ArgumentException($"there must be at least one acceptance between start and end");

            AcceptanceDuration = acceptanceDuration;
            AcceptanceStart = acceptanceStart;
            AcceptanceEnd = acceptanceEnd;
        }
    }
}
