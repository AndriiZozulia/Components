﻿using System;

namespace Hospital.BLL.Models.Schelude.Abstractions
{
    public interface ISchedule
    {
        TimeSpan AcceptanceDuration { get; }
        TimeSpan AcceptanceStart { get; }
        TimeSpan AcceptanceEnd { get; }
    }
}
