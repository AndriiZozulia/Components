﻿using System;
using Hospital.BLL.Models.Appointments.Abstractions;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Models.Doctors.Abstractions;

namespace Hospital.BLL.Models.Appointments
{
    public class Appointment : IAppointment
    {
        public IDoctor Doctor { get; }
        public IClient Client { get; }
        public DateTime StartDate { get; }
        public DateTime EndDate { get; }

        public Appointment(
            IDoctor doctor,
            IClient client,
            DateTime startDate,
            DateTime endDate)
        {
            if (startDate >= endDate)
                throw new ArgumentException($"{nameof(endDate)} must be greater than {nameof(startDate)}");

            Doctor = doctor ?? throw new ArgumentNullException(nameof(doctor));
            Client = client ?? throw new ArgumentNullException(nameof(client));
            StartDate = startDate;
            EndDate = endDate;
        }
    }
}
