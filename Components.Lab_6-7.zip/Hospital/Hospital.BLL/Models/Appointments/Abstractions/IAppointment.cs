﻿using System;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Models.Doctors.Abstractions;

namespace Hospital.BLL.Models.Appointments.Abstractions
{
    public interface IAppointment
    {
        IDoctor Doctor { get; }
        IClient Client { get; }

        DateTime StartDate { get; }
        DateTime EndDate { get; }
    }
}
