﻿namespace Hospital.BLL.Models.Doctors
{
    public enum DoctorTypes
    {
        Surgeon,
        Oculist
    }
}
