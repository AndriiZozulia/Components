﻿using System;
using Hospital.BLL.Models.Core.Abstractions;
using Hospital.BLL.Models.Schelude.Abstractions;

namespace Hospital.BLL.Models.Doctors.Abstractions
{
    public interface IDoctor : IEntity<Guid>
    {
        DoctorTypes Type { get; }

        string FirstName { get; }
        string LastName { get; }

        int RoomNumber { get; }

        ISchedule Schedule { get; }
    }
}
