﻿using System;
using Hospital.BLL.Models.Core.Abstractions;
using Hospital.BLL.Models.Schelude.Abstractions;

namespace Hospital.BLL.Models.Doctors.Abstractions
{
    public abstract class DoctorBase : EntityBase<Guid>, IDoctor
    {
        public DoctorTypes Type { get; }
        public string FirstName { get; }
        public string LastName { get; }
        public int RoomNumber { get; }
        public ISchedule Schedule { get; }

        protected DoctorBase(
            Guid id,
            DoctorTypes type,
            string firstName,
            string lastName,
            int roomNumber,
            ISchedule schedule) : base(id)
        {
            if (id == Guid.Empty)
                throw new ArgumentException(nameof(id));

            if (string.IsNullOrEmpty(firstName))
                throw new ArgumentException(nameof(firstName));

            if (string.IsNullOrEmpty(lastName))
                throw new ArgumentException(nameof(lastName));

            if (roomNumber <= 0)
                throw new ArgumentException($"{nameof(roomNumber)} must be greater than 0");

            Type = type;
            FirstName = firstName;
            LastName = lastName;
            RoomNumber = roomNumber;
            Schedule = schedule ?? throw new ArgumentNullException(nameof(schedule));
        }
    }
}
