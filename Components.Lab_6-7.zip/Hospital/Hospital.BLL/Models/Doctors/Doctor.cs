﻿using System;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.BLL.Models.Schelude.Abstractions;

namespace Hospital.BLL.Models.Doctors
{
    public class Doctor : DoctorBase
    {
        public Doctor(
            Guid id,
            DoctorTypes type,
            string firstName,
            string lastName,
            int roomNumber,
            ISchedule schedule) : base(id, type, firstName, lastName, roomNumber, schedule)
        {
        }
    }
}
