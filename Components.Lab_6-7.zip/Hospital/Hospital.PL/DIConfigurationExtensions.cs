﻿using AutoMapper;

using Microsoft.Extensions.DependencyInjection;

namespace Hospital.PL
{
    public static class DIConfigurationExtensions
    {
        public static IServiceCollection AddPLServices(this IServiceCollection services)
        {
            services.AddAutoMapper();
            return services;
        }
    }
}
