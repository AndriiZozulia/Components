﻿using System;
using Newtonsoft.Json;

namespace Hospital.PL.Models
{
    public class ClientModel
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }
    }
}
