﻿using System;
using Newtonsoft.Json;

namespace Hospital.PL.Models
{
    public class AppointmentModel
    {
        [JsonProperty("startDate")]
        public DateTime StartDate { get; set; }

        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        [JsonProperty("doctor")]
        public DoctorModel Doctor { get; set; }

        [JsonProperty("client")]
        public ClientModel Client { get; set; }
    }
}
