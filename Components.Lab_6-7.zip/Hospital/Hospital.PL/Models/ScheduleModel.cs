﻿using System;
using Newtonsoft.Json;

namespace Hospital.PL.Models
{
    public class ScheduleModel
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }
        [JsonProperty("acceptanceDuration")]
        public TimeSpan AcceptanceDuration { get; set; }
        [JsonProperty("acceptanceStart")]
        public TimeSpan AcceptanceStart { get; set; }
        [JsonProperty("acceptanceEnd")]
        public TimeSpan AcceptanceEnd { get; set; }
    }
}
