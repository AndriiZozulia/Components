﻿using Newtonsoft.Json;

namespace Hospital.PL.Models.RequestModels
{
    public class AddClientRequestModel
    {
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }
    }
}
