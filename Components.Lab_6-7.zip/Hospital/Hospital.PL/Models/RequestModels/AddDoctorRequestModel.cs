using Newtonsoft.Json;

namespace Hospital.PL.Models.RequestModels
{
    public class AddDoctorRequestModel
    {   
        [JsonProperty("type")]
        public int Type { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("roomNumber")]
        public int RoomNumber { get; set; }

        [JsonProperty("schedule")]
        public ScheduleModel Schedule { get; set; }
    }
}