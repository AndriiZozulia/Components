﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.PL.Controllers.Abstractions;
using Hospital.PL.Models;
using Hospital.PL.Models.RequestModels;
using Microsoft.AspNetCore.Mvc;

namespace Hospital.PL.Controllers
{
    public class ClientsController : HospitalController
    {
        private readonly IClientService _clientService;
        private readonly IMapper _mapper;

        public ClientsController(
            IClientService clientsService,
            IMapper mapper)
        {
            _clientService = clientsService ?? throw new ArgumentNullException(nameof(clientsService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        [HttpGet("clients")]
        public async Task<IActionResult> GetAllClientsAsync()
        {
            var clients = await _clientService.GetAllAsync();

            var responseModels = _mapper.Map<IReadOnlyCollection<ClientModel>>(clients);

            return Ok(responseModels);
        }

        [HttpGet("clients/{clientId}")]
        public async Task<IActionResult> GetClientAsync(Guid clientId)
        {
            var client = await _clientService.GetAsync(clientId);

            var responseModel = _mapper.Map<ClientModel>(client);

            return Ok(responseModel);
        }

        [HttpPost("clients")]
        public async Task<IActionResult> AddClientAsync([FromBody] AddClientRequestModel addClientRequestModel)
        {
            var client = _mapper.Map<IClient>(addClientRequestModel);

            await _clientService.AddAsync(client);

            return Ok();
        }
    }
}
