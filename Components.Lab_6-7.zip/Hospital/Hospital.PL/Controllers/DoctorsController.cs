﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.PL.Controllers.Abstractions;
using Hospital.PL.Models;
using Hospital.PL.Models.RequestModels;
using Microsoft.AspNetCore.Mvc;

namespace Hospital.PL.Controllers
{
    public class DoctorsController : HospitalController
    {
        private readonly IDoctorService _doctorService;
        private readonly IMapper _mapper;

        public DoctorsController(
            IDoctorService doctorService,
            IMapper mapper)
        {
            _doctorService = doctorService ?? throw new ArgumentNullException(nameof(doctorService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        [HttpGet("doctors")]
        public async Task<IActionResult> GetAllDoctors()
        {
            var doctors = await _doctorService.GetAllAsync();

            var responseModels = _mapper.Map<IReadOnlyCollection<DoctorModel>>(doctors);

            return Ok(responseModels);
        }

        [HttpGet("doctors/{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var doctor = await _doctorService.GetAsync(id);

            var responseModel = _mapper.Map<DoctorModel>(doctor);

            return Ok(responseModel);
        }
        
        [HttpPost("doctors")]
        public async Task<IActionResult> AddDoctorAsync([FromBody] AddDoctorRequestModel addDoctorRequestModel)
        {
            if (addDoctorRequestModel == null)
                return BadRequest();
            
            var client = _mapper.Map<IDoctor>(addDoctorRequestModel);

            await _doctorService.AddAsync(client);

            return Ok();
        }
    }
}
