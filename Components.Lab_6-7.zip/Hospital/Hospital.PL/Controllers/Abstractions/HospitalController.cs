﻿using Microsoft.AspNetCore.Mvc;

namespace Hospital.PL.Controllers.Abstractions
{
    [Route("api/v1/hospital")]
    public abstract class HospitalController : ControllerBase
    {
    }
}
