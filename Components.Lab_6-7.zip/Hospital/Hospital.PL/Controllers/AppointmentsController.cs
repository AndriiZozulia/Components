﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Hospital.BLL.Models.Appointments.Abstractions;
using Hospital.BLL.Services.Abstractions;
using Hospital.PL.Controllers.Abstractions;
using Hospital.PL.Models;
using Hospital.PL.Models.RequestModels;
using Microsoft.AspNetCore.Mvc;

namespace Hospital.PL.Controllers
{
    public class AppointmentsController : HospitalController
    {
        private readonly IAppointmentService _appointmentService;
        private readonly IMapper _mapper;

        public AppointmentsController(
            IAppointmentService appointmentService,
            IMapper mapper)
        {
            _appointmentService = appointmentService ?? throw new ArgumentNullException(nameof(appointmentService));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        [HttpGet("doctors/{doctorId}/appointments")]
        public async Task<IActionResult> GetByDoctorAsync(Guid doctorId)
        {
            var appointments = await _appointmentService.GetAllByDoctorIdAsync(doctorId);

            var responseModels = _mapper.Map<IReadOnlyCollection<AppointmentModel>>(appointments);

            return Ok(responseModels);
        }

        [HttpGet("clients/{clientId}/appointments")]
        public async Task<IActionResult> GetByClientAsync(Guid clientId)
        {
            var appointments = await _appointmentService.GetAllByClientIdAsync(clientId);

            var responseModels = _mapper.Map<IReadOnlyCollection<AppointmentModel>>(appointments);

            return Ok(responseModels);
        }

        [HttpPost("appointments")]
        public async Task<IActionResult> CreateAppointment([FromBody] CreateAppointmentRequestModel appointmentModel)
        {
            if (appointmentModel == null)
                return BadRequest();

            await _appointmentService.CreateAppointmentAsync(
                appointmentModel.StartDate,
                appointmentModel.EndDate,
                appointmentModel.ClientId,
                appointmentModel.DoctorId);

            return Ok();
        }
    }
}
