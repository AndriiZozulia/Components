﻿using Hospital.BLL;
using Hospital.PL.Middlewares;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace Hospital.PL
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddBLLServices();
            services.AddPLServices();

            services
                .AddMvcCore()
                .AddJsonFormatters()
                .AddCors();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseMiddleware<ExceptionHandlingMiddleware>();
            app.UseCors(builder =>
            {
                builder.AllowAnyHeader();
                builder.AllowAnyMethod();
                builder.AllowAnyOrigin();
                builder.AllowCredentials();
            });
            app.UseMvc();
        }
    }
}
