﻿using AutoMapper;
using Hospital.BLL.Models.Schelude;
using Hospital.BLL.Models.Schelude.Abstractions;
using Hospital.PL.Models;

namespace Hospital.PL.Mapping
{
    public class ScheduleProfile : Profile
    {
        public ScheduleProfile()
        {
            CreateMap<ISchedule, ScheduleModel>()
                .ConstructUsing(schedule => new ScheduleModel()
                {
                    AcceptanceStart = schedule.AcceptanceStart,
                    AcceptanceDuration = schedule.AcceptanceDuration,
                    AcceptanceEnd = schedule.AcceptanceEnd
                });

            CreateMap<ScheduleModel, ISchedule>()
                .ConstructUsing(model =>
                    new Schedule(model.AcceptanceDuration, model.AcceptanceStart, model.AcceptanceEnd));
        }
    }
}
