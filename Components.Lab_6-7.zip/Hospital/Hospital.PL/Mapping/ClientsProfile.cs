﻿using System;
using AutoMapper;
using Hospital.BLL.Models.Clients;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.PL.Models;
using Hospital.PL.Models.RequestModels;

namespace Hospital.PL.Mapping
{
    public class ClientsProfile : Profile
    {
        public ClientsProfile()
        {
            CreateMap<IClient, ClientModel>()
                .ConstructUsing(client => new ClientModel()
                {
                    Id = client.Id,
                    LastName = client.LastName,
                    FirstName = client.FirstName
                });

            CreateMap<ClientModel, IClient>()
                .ConstructUsing(model => new Client(model.Id, model.FirstName, model.LastName));

            CreateMap<AddClientRequestModel, IClient>()
                .ConstructUsing(model => new Client(Guid.NewGuid(), model.FirstName, model.LastName));
        }
    }
}
