﻿using System;
using AutoMapper;
using Hospital.BLL.Models.Doctors;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.BLL.Models.Schelude;
using Hospital.BLL.Models.Schelude.Abstractions;
using Hospital.PL.Models;
using Hospital.PL.Models.RequestModels;

namespace Hospital.PL.Mapping
{
    public class DoctorProfile : Profile
    {
        public DoctorProfile()
        {
            CreateMap<IDoctor, DoctorModel>().ConstructUsing(doctor => new DoctorModel()
            {
                Id = doctor.Id,
                LastName = doctor.LastName,
                RoomNumber = doctor.RoomNumber,
                FirstName = doctor.FirstName,
                Type = (int) doctor.Type
            });

            CreateMap<DoctorModel, IDoctor>()
                .ConstructUsing((model, context) => 
                    new Doctor(
                        model.Id,
                        (DoctorTypes) model.Type,
                        model.FirstName,
                        model.LastName, 
                        model.RoomNumber,
                        context.Mapper.Map<ISchedule>(model.Schedule)));
    
            CreateMap<AddDoctorRequestModel, IDoctor>()
                .ConstructUsing((model, context) => new Doctor(Guid.NewGuid(), 
                    (DoctorTypes)model.Type,
                    model.FirstName,
                    model.LastName,
                    model.RoomNumber,
                    context.Mapper.Map<ISchedule>(model.Schedule)));
        }
    }
}
