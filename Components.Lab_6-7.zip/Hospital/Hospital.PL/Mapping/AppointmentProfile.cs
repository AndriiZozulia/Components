﻿using AutoMapper;
using Hospital.BLL.Models.Appointments;
using Hospital.BLL.Models.Appointments.Abstractions;
using Hospital.BLL.Models.Clients.Abstractions;
using Hospital.BLL.Models.Doctors.Abstractions;
using Hospital.PL.Models;

namespace Hospital.PL.Mapping
{
    public class AppointmentProfile : Profile
    {
        public AppointmentProfile()
        {
            CreateMap<IAppointment, AppointmentModel>()
                .ConstructUsing((appointment, context) => new AppointmentModel()
                {
                    Client = context.Mapper.Map<ClientModel>(appointment.Client),
                    Doctor = context.Mapper.Map<DoctorModel>(appointment.Doctor),
                    StartDate = appointment.StartDate,
                    EndDate = appointment.EndDate
                });

            CreateMap<AppointmentModel, IAppointment>()
                .ConstructUsing((appointmentModel, context) =>
                    new Appointment(
                        context.Mapper.Map<IDoctor>(appointmentModel.Doctor),
                        context.Mapper.Map<IClient>(appointmentModel.Client),
                        appointmentModel.StartDate,
                        appointmentModel.EndDate));
        }
    }
}
