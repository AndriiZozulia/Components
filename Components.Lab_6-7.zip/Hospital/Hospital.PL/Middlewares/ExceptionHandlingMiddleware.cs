﻿using System;
using System.Threading.Tasks;
using Hospital.BLL.Exceptions;
using Microsoft.AspNetCore.Http;

namespace Hospital.PL.Middlewares
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;

        public ExceptionHandlingMiddleware(RequestDelegate next)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
        }

        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                await _next.Invoke(httpContext);
            }
            catch (ValidationException e)
            {
                httpContext.Response.StatusCode = 400;
                await httpContext.Response.WriteAsync(e.ToString());
            }
        }
    }
}
